function o = myF2(x,y,z)
o = (1 + x^(0.5) + y^(-1) + z^(-1.5))^2;
end