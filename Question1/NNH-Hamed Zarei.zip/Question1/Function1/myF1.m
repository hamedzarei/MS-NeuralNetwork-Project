function z = myF1(x,y)
z = (sin(x)/x)*(sin(y)/y);
end