function [ output_args ] = f1( input_args )
%F1 Summary of this function goes here
%   Detailed explanation goes here


end

